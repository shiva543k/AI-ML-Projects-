# 03 Customer Churn Prediction

Project details and setup instructions.