# 05 Image Classification

Project details and setup instructions.