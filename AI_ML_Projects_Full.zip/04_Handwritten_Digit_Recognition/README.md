# 04 Handwritten Digit Recognition

Project details and setup instructions.