# 01 COVID19 Data Analysis

Project details and setup instructions.