# 10 Model Deployment Flask

Project details and setup instructions.