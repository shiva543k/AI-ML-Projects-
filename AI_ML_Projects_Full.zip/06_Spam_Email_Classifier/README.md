# 06 Spam Email Classifier

Project details and setup instructions.