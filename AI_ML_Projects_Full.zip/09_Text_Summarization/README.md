# 09 Text Summarization

Project details and setup instructions.