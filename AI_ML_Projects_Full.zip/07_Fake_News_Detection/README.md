# 07 Fake News Detection

Project details and setup instructions.