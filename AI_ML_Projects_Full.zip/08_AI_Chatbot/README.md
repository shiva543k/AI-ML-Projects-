# 08 AI Chatbot

Project details and setup instructions.