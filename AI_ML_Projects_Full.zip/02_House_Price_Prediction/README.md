# 02 House Price Prediction

Project details and setup instructions.